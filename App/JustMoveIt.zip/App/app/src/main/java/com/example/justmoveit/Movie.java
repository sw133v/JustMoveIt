package com.example.justmoveit;

public class Movie {
    public String name, category, releaseDate;
    public String img; // 이미지 url
    public float rating;

}
